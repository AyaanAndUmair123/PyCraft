import pygame as pg
import sys, json, os
import subprocess

pg.init()

# Screen
WIDTH, HEIGHT = 700, 500
screen = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("PyCraft")

# Colors
SKY = (0, 149, 255)
WHITE = (255, 255, 255)
GRAY = (180, 180, 180)
DARK_GRAY = (140, 140, 140)

# Fonts
title_font = pg.font.SysFont("arial", 72, bold=True)
button_font = pg.font.SysFont("arial", 36, bold=True)

# Button class
class Button:
    def __init__(self, text, x, y, w, h):
        self.text = text
        self.rect = pg.Rect(x, y, w, h)

    def draw(self):
        color = DARK_GRAY if self.rect.collidepoint(pg.mouse.get_pos()) else GRAY
        pg.draw.rect(screen, color, self.rect, border_radius=8)

        txt = button_font.render(self.text, True, WHITE)
        txt_rect = txt.get_rect(center=self.rect.center)
        screen.blit(txt, txt_rect)

    def clicked(self, event):
        return (
            event.type == pg.MOUSEBUTTONDOWN and
            event.button == 1 and
            self.rect.collidepoint(event.pos)
        )

# Buttons
button_w, button_h = 240, 60
center_x = (WIDTH - button_w) // 2

play_btn = Button("Play", center_x, 240, button_w, button_h)
quit_btn = Button("Quit", center_x, 310, button_w, button_h)

def draw_title():
    text = title_font.render("PyCraft", True, WHITE)
    rect = text.get_rect(centerx=WIDTH // 2, y=80)
    screen.blit(text, rect)

def launch_game():
    pg.quit()
    subprocess.run([sys.executable, "game.py"])
    sys.exit()

running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        if play_btn.clicked(event):
            launch_game()
        if quit_btn.clicked(event):
            running = False

    screen.fill(SKY)
    draw_title()

    play_btn.draw()
    quit_btn.draw()

    pg.display.flip()

pg.quit()
