import pygame as pg
import subprocess as sp
import sys, os, pickle, json, random
from noise import pnoise1, pnoise2

# ================= INIT =================
pg.init()
WIDTH, HEIGHT = 800, 600
TILE = 32
FPS = 60
screen = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("PyCraft")
clock = pg.time.Clock()

# ================= PATHS =================
BASE = "./gamefiles"
WORLD_DIR = f"{BASE}/worlds/World1"
WORLD_FILE = f"{WORLD_DIR}/level.dat"
SETTINGS_FILE = f"{BASE}/settings/settings.json"
os.makedirs(WORLD_DIR, exist_ok=True)
os.makedirs(os.path.dirname(SETTINGS_FILE), exist_ok=True)

# ================= SETTINGS =================
def load_settings():
    if not os.path.exists(SETTINGS_FILE):
        return {"fullscreen": False, "show_fps": False, "auto_step": True}
    return json.load(open(SETTINGS_FILE))

def save_settings(s):
    json.dump(s, open(SETTINGS_FILE, "w"), indent=4)

settings = load_settings()

# ================= CONSTANTS =================
GRAVITY = 0.8
JUMP_FORCE = -12
CHUNK = 16
SEED = 1337
SURFACE_Y = 40
BEDROCK_Y = 90
menu_state = "game"   # game / pause / settings

# ================= BLOCK IDS =================
AIR, GRASS, DIRT, STONE, BEDROCK, WOOD, LEAVES, COAL, IRON = range(9)

# ================= HOTBAR =================
hotbar = [GRASS, DIRT, STONE, WOOD]
selected = 0

# ================= TEXTURES =================
def tex(name):
    return pg.transform.scale(
        pg.image.load(f"{BASE}/assets/textures/blocks/{name}.png"),
        (TILE, TILE)
    )

BLOCK_TEX = {
    GRASS: tex("grass"),
    DIRT: tex("dirt"),
    STONE: tex("stone"),
    BEDROCK: tex("bedrock"),
    WOOD: tex("wood"),
    LEAVES: tex("leaves"),
    COAL: tex("coal"),
    IRON: tex("iron"),
}

# ================= WORLD =================
chunks = {}

def generate_chunk(cx, cy):
    chunk = [[AIR]*CHUNK for _ in range(CHUNK)]
    for lx in range(CHUNK):
        wx = cx*CHUNK + lx
        height = int(pnoise1(wx/30, octaves=4, base=SEED)*8 + SURFACE_Y)

        for ly in range(CHUNK):
            wy = cy*CHUNK + ly

            if wy == BEDROCK_Y:
                block = BEDROCK
            elif wy > BEDROCK_Y:
                block = STONE
            elif wy == height:
                block = GRASS
            elif height < wy <= height+3:
                block = DIRT
            elif wy > height:
                cave = pnoise2(wx/18, wy/18, octaves=2, base=SEED)
                if cave > 0.35:
                    block = AIR
                else:
                    ore = pnoise2(wx/10, wy/10, base=SEED)
                    if ore > 0.45:
                        block = COAL
                    elif ore < -0.45:
                        block = IRON
                    else:
                        block = STONE
            else:
                block = AIR

            chunk[ly][lx] = block
    return chunk

def decorate_chunk(cx, cy):
    chunk = chunks[(cx, cy)]
    for lx in range(CHUNK):
        for ly in range(CHUNK):
            if chunk[ly][lx] == GRASS and random.random() < 0.08:
                place_tree(cx, cy, lx, ly)
                break

def place_tree(cx, cy, lx, ly):
    h = random.randint(4, 6)
    for i in range(h):
        if ly-i < 0: return
        chunks[(cx, cy)][ly-i][lx] = WOOD

    top = ly - h
    for x in range(-2, 3):
        for y in range(-2, 3):
            ax, ay = lx+x, top+y
            if 0 <= ax < CHUNK and 0 <= ay < CHUNK:
                if abs(x)+abs(y) <= 3:
                    chunks[(cx, cy)][ay][ax] = LEAVES

def get_chunk(cx, cy):
    if (cx, cy) not in chunks:
        chunks[(cx, cy)] = generate_chunk(cx, cy)
        decorate_chunk(cx, cy)
    return chunks[(cx, cy)]

def get_block(x, y):
    cx, cy = x//CHUNK, y//CHUNK
    return get_chunk(cx, cy)[y%CHUNK][x%CHUNK]

def set_block(x, y, b):
    cx, cy = x//CHUNK, y//CHUNK
    get_chunk(cx, cy)[y%CHUNK][x%CHUNK] = b

# ================= LOAD WORLD =================
if os.path.exists(WORLD_FILE):
    chunks = pickle.load(open(WORLD_FILE, "rb"))

# ================= PLAYER =================
player = pg.Rect(200, 100, 14, 48)  # narrower hitbox
vel_y = 0
on_ground = False

img_r = pg.transform.scale(pg.image.load(f"{BASE}/assets/textures/plr.png"), (32,48))
img_l = pg.transform.flip(img_r, True, False)
plr_img = img_r

camera_x = camera_y = 0

# ================= COLLISION =================
def nearby_tiles(r):
    tiles = []
    for y in range(r.top//TILE-1, r.bottom//TILE+1):
        for x in range(r.left//TILE-1, r.right//TILE+1):
            if get_block(x,y) != AIR:
                tiles.append(pg.Rect(x*TILE, y*TILE, TILE, TILE))
    return tiles

# ================= DRAW =================
def draw_world():
    sx = camera_x//TILE - 2
    ex = (camera_x+WIDTH)//TILE + 2
    sy = camera_y//TILE - 2
    ey = (camera_y+HEIGHT)//TILE + 2
    for y in range(sy, ey):
        for x in range(sx, ex):
            b = get_block(x,y)
            if b != AIR:
                screen.blit(BLOCK_TEX[b], (x*TILE-camera_x, y*TILE-camera_y))

def draw_hotbar():
    bar_w = 60*len(hotbar)
    x = WIDTH//2 - bar_w//2
    y = HEIGHT - 50
    pg.draw.rect(screen, (40,40,40), (x,y,bar_w,40))
    for i,b in enumerate(hotbar):
        screen.blit(pg.transform.scale(BLOCK_TEX[b],(24,24)), (x+i*60+10,y+8))
        if i==selected:
            pg.draw.rect(screen,(255,255,255),(x+i*60+8,y+6,28,28),2)

def draw_overlay(title, lines):
    overlay = pg.Surface((WIDTH, HEIGHT), pg.SRCALPHA)
    overlay.fill((0,0,0,160))
    screen.blit(overlay,(0,0))
    tfont = pg.font.SysFont("arial",42,True)
    sfont = pg.font.SysFont("arial",24)
    screen.blit(tfont.render(title,True,(255,255,255)),
                (WIDTH//2-80,200))
    for i,l in enumerate(lines):
        screen.blit(sfont.render(l,True,(255,255,255)),
                    (WIDTH//2-110,260+i*30))

# ================= SAVE =================
def save_world():
    pickle.dump(chunks, open(WORLD_FILE, "wb"))

# ================= MAIN LOOP =================
running = True
while running:
    clock.tick(FPS)

    for e in pg.event.get():
        if e.type == pg.QUIT:
            save_world()
            pg.quit()
            sp.Popen([sys.executable, "./main.py"])
            sys.exit()

        if e.type == pg.KEYDOWN:
            if menu_state == "game" and e.key == pg.K_ESCAPE:
                menu_state = "pause"

            elif menu_state == "pause":
                if e.key == pg.K_ESCAPE: menu_state = "game"
                elif e.key == pg.K_s: menu_state = "settings"
                elif e.key == pg.K_q:
                    save_world()
                    pg.quit()

                    sys.exit()

            elif menu_state == "settings":
                if e.key == pg.K_ESCAPE:
                    menu_state = "pause"
                elif e.key == pg.K_f:
                    settings["fullscreen"] = not settings["fullscreen"]
                    save_settings(settings)
                    screen = pg.display.set_mode(
                        (WIDTH,HEIGHT),
                        pg.FULLSCREEN if settings["fullscreen"] else 0)
                elif e.key == pg.K_g:
                    settings["show_fps"] = not settings["show_fps"]
                    save_settings(settings)
                elif e.key == pg.K_h:
                    settings["auto_step"] = not settings["auto_step"]
                    save_settings(settings)

        if e.type == pg.MOUSEBUTTONDOWN and menu_state == "game":
            mx,my = e.pos
            wx = (mx+camera_x)//TILE
            wy = (my+camera_y)//TILE
            if abs(wx*TILE-player.centerx)<100:
                if e.button==1 and get_block(wx,wy) not in (AIR,BEDROCK):
                    set_block(wx,wy,AIR)
                elif e.button==3 and get_block(wx,wy)==AIR:
                    set_block(wx,wy,hotbar[selected])

    if menu_state == "game":
        keys = pg.key.get_pressed()
        dx = 0
        if keys[pg.K_a]: dx,plr_img=-4,img_l
        if keys[pg.K_d]: dx,plr_img=4,img_r
        if keys[pg.K_SPACE] and on_ground:
            vel_y = JUMP_FORCE

        vel_y += GRAVITY
        # ===== Horizontal movement & step-up =====
        player.x += dx
        for t in nearby_tiles(player):
            if player.colliderect(t):

                # Try step-up if enabled
                if settings["auto_step"]:
                    step_height = TILE  # 1 block
                    player.y -= step_height

                    if any(player.colliderect(o) for o in nearby_tiles(player)):
                        # Step failed → revert
                        player.y += step_height
                        player.x -= dx
                    else:
                        # Step success
                        on_ground = True

                else:
                    player.x -= dx


        # ===== Vertical movement & collision =====
        on_ground = False
        player.y += vel_y

        for t in nearby_tiles(player):
            if player.colliderect(t):

                # Falling DOWN
                if vel_y > 0:
                    player.bottom = t.top
                    vel_y = 0
                    on_ground = True

                # Jumping UP (head hit)
                elif vel_y < 0:
                    player.top = t.bottom
                    vel_y = 0


        camera_x = player.centerx-WIDTH//2
        camera_y = player.centery-HEIGHT//2

    screen.fill((135,206,235))
    draw_world()
    screen.blit(
        plr_img,
        (player.x - camera_x - 8, player.y - camera_y)
    )
    draw_hotbar()

    if menu_state == "pause":
        draw_overlay("Paused",["ESC - Resume","S - Settings","Q - Quit"])
    elif menu_state == "settings":
        draw_overlay("Settings",[
            f"F - Fullscreen: {'ON' if settings['fullscreen'] else 'OFF'}",
            f"G - Show FPS: {'ON' if settings['show_fps'] else 'OFF'}",
            f"H - Auto Jump: {'ON' if settings['auto_step'] else 'OFF'}",
            "ESC - Back"
        ])

    if settings["show_fps"]:
        screen.blit(pg.font.SysFont(None,24).render(
            f"FPS: {int(clock.get_fps())}",True,(255,255,255)),(10,10))

    pg.display.flip()
