# GAME FILE — DO NOT PUT OPTIONS.PY OR MAIN.PY CODE HERE

import pygame as pg
import sys
import os
import pickle

# ---------- INIT ----------
pg.init()

WIDTH, HEIGHT = 800, 600
TILE = 32
GRAVITY = 0.8
JUMP_FORCE = -12

COLS = 100
ROWS = 60

screen = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("PyCraft - Alpha")

clock = pg.time.Clock()

# ---------- PATHS ----------
WORLD_DIR = "./gamefiles/worlds/World1"
WORLD_FILE = os.path.join(WORLD_DIR, "level.dat")
os.makedirs(WORLD_DIR, exist_ok=True)

# ---------- COLORS ----------
SKY = (135, 206, 235)
GRASS_C = (95, 159, 53)
DIRT_C = (121, 85, 58)
COBBLE_C = (120, 120, 120)
BEDROCK_C = (30, 30, 30)
UI_BG = (40, 40, 40)
UI_SEL = (255, 255, 255)

# ---------- BLOCKS ----------
AIR = 0
GRASS = 1
DIRT = 2
COBBLE = 3
BEDROCK = 4

BLOCK_COLORS = {
    GRASS: GRASS_C,
    DIRT: DIRT_C,
    COBBLE: COBBLE_C,
    BEDROCK: BEDROCK_C
}

# ---------- WORLD ----------
world = [[AIR for _ in range(COLS)] for _ in range(ROWS)]
surface = ROWS // 2

def generate_world():
    for y in range(ROWS):
        for x in range(COLS):
            if y == ROWS - 1:
                world[y][x] = BEDROCK
            elif y == surface:
                world[y][x] = GRASS
            elif surface < y <= surface + 3:
                world[y][x] = DIRT
            elif y > surface + 3:
                world[y][x] = COBBLE

def load_world():
    global world
    if os.path.exists(WORLD_FILE):
        with open(WORLD_FILE, "rb") as f:
            world = pickle.load(f)
        print("World loaded")
    else:
        generate_world()
        print("New world generated")

def save_world():
    with open(WORLD_FILE, "wb") as f:
        pickle.dump(world, f)
    print("World saved")

load_world()

# ---------- PLAYER ----------
plr_img_right = pg.image.load(
    "./gamefiles/assets/textures/plr.png"
).convert_alpha()
plr_img_right = pg.transform.scale(plr_img_right, (32, 48))
plr_img_left = pg.transform.flip(plr_img_right, True, False)
plr_img = plr_img_right

player = pg.Rect(200, 100, 32, 48)
vel_y = 0
on_ground = False

# ---------- INVENTORY ----------
hotbar = [GRASS, DIRT, COBBLE]
selected = 0

# ---------- CAMERA ----------
camera_x = 0
camera_y = 0

# ---------- FUNCTIONS ----------
def nearby_tiles(rect):
    tiles = []
    sx = rect.left // TILE - 1
    ex = rect.right // TILE + 1
    sy = rect.top // TILE - 1
    ey = rect.bottom // TILE + 1

    for y in range(sy, ey + 1):
        for x in range(sx, ex + 1):
            if 0 <= x < COLS and 0 <= y < ROWS:
                if world[y][x] != AIR:
                    tiles.append(pg.Rect(x*TILE, y*TILE, TILE, TILE))
    return tiles

def draw_world():
    for y in range(ROWS):
        for x in range(COLS):
            b = world[y][x]
            if b != AIR:
                screen_x = x*TILE - camera_x
                screen_y = y*TILE - camera_y
                pg.draw.rect(
                    screen,
                    BLOCK_COLORS[b],
                    (screen_x, screen_y, TILE, TILE)
                )

def draw_hotbar():
    bar_w = 200
    bar_x = WIDTH//2 - bar_w//2
    bar_y = HEIGHT - 50

    pg.draw.rect(screen, UI_BG, (bar_x, bar_y, bar_w, 40))

    for i, block in enumerate(hotbar):
        x = bar_x + i*60 + 10
        y = bar_y + 8
        pg.draw.rect(screen, BLOCK_COLORS[block], (x, y, 24, 24))
        if i == selected:
            pg.draw.rect(screen, UI_SEL, (x-2, y-2, 28, 28), 2)

# ---------- GAME LOOP ----------
running = True
while running:
    clock.tick(60)

    for event in pg.event.get():
        if event.type == pg.QUIT:
            save_world()
            running = False

        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                save_world()
                pg.quit()
                os.execv(sys.executable, [sys.executable, "main.py"])

            if event.key == pg.K_1: selected = 0
            if event.key == pg.K_2: selected = 1
            if event.key == pg.K_3: selected = 2

        if event.type == pg.MOUSEBUTTONDOWN:
            mx, my = event.pos
            wx = (mx + camera_x) // TILE
            wy = (my + camera_y) // TILE

            if 0 <= wx < COLS and 0 <= wy < ROWS:
                if abs(wx*TILE - player.centerx) < 100 and abs(wy*TILE - player.centery) < 100:

                    if event.button == 1:
                        if world[wy][wx] not in (AIR, BEDROCK):
                            world[wy][wx] = AIR

                    if event.button == 3:
                        if world[wy][wx] == AIR:
                            world[wy][wx] = hotbar[selected]

    # ---------- MOVEMENT ----------
    keys = pg.key.get_pressed()
    dx = 0
    speed = 4

    if keys[pg.K_a]:
        dx = -speed
        plr_img = plr_img_left
    if keys[pg.K_d]:
        dx = speed
        plr_img = plr_img_right
    if keys[pg.K_SPACE] and on_ground:
        vel_y = JUMP_FORCE

    vel_y += GRAVITY
    dy = vel_y

    player.x += dx
    for tile in nearby_tiles(player):
        if player.colliderect(tile):
            player.x -= dx

    on_ground = False
    player.y += dy
    for tile in nearby_tiles(player):
        if player.colliderect(tile):
            if dy > 0:
                player.bottom = tile.top
                vel_y = 0
                on_ground = True
            elif dy < 0:
                player.top = tile.bottom
                vel_y = 0

    # ---------- CAMERA ----------
    camera_x = player.centerx - WIDTH // 2
    camera_y = player.centery - HEIGHT // 2

    # ---------- DRAW ----------
    screen.fill(SKY)
    draw_world()
    screen.blit(plr_img, (player.x - camera_x, player.y - camera_y))
    draw_hotbar()

    pg.display.flip()

pg.quit()
sys.exit()
