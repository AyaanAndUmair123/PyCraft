import pygame as pg
import sys
import os
import subprocess as sp
# ---------- INIT ----------
pg.init()

WIDTH, HEIGHT = 800, 600
TILE = 32
GRAVITY = 0.8
JUMP_FORCE = -12

COLS = WIDTH // TILE
ROWS = HEIGHT // TILE

screen = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption("PyCraft - Alpha")

clock = pg.time.Clock()

# ---------- COLORS ----------
SKY = (135, 206, 235)
GRASS_C = (95, 159, 53)
DIRT_C = (121, 85, 58)
COBBLE_C = (120, 120, 120)
UI_BG = (40, 40, 40)
UI_SEL = (255, 255, 255)

# ---------- BLOCKS ----------
AIR = 0
GRASS = 1
DIRT = 2
COBBLE = 3

BLOCK_COLORS = {
    GRASS: GRASS_C,
    DIRT: DIRT_C,
    COBBLE: COBBLE_C
}

# ---------- WORLD ----------
world = [[AIR for _ in range(COLS)] for _ in range(ROWS)]
surface = ROWS // 2

for y in range(ROWS):
    for x in range(COLS):
        if y == surface:
            world[y][x] = GRASS
        elif surface < y <= surface + 3:
            world[y][x] = DIRT
        elif y > surface + 3:
            world[y][x] = COBBLE

# ---------- PLAYER ----------
plr_img = pg.image.load(
    "./gamefiles/assets/textures/plr.png"
).convert_alpha()
plr_img = pg.transform.scale(plr_img, (32, 48))

player = pg.Rect(100, 100, 32, 48)
vel_y = 0
on_ground = False

# ---------- INVENTORY (HOTBAR) ----------
hotbar = [GRASS, DIRT, COBBLE]
selected = 0
font = pg.font.SysFont("arial", 18, bold=True)

# ---------- FUNCTIONS ----------
def draw_world():
    for y in range(ROWS):
        for x in range(COLS):
            b = world[y][x]
            if b != AIR:
                pg.draw.rect(
                    screen,
                    BLOCK_COLORS[b],
                    (x*TILE, y*TILE, TILE, TILE)
                )

def get_tile(pos):
    return pos[0] // TILE, pos[1] // TILE

def is_solid(tx, ty):
    if 0 <= tx < COLS and 0 <= ty < ROWS:
        return world[ty][tx] != AIR
    return False

def draw_hotbar():
    bar_w = 200
    bar_x = WIDTH//2 - bar_w//2
    bar_y = HEIGHT - 50

    pg.draw.rect(screen, UI_BG, (bar_x, bar_y, bar_w, 40))

    for i, block in enumerate(hotbar):
        x = bar_x + i*60 + 10
        y = bar_y + 8

        pg.draw.rect(screen, BLOCK_COLORS[block], (x, y, 24, 24))

        if i == selected:
            pg.draw.rect(screen, UI_SEL, (x-2, y-2, 28, 28), 2)

# ---------- GAME LOOP ----------
running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False

        if event.type == pg.KEYDOWN:
            if event.key == pg.K_ESCAPE:
                pg.quit()
                sp.run([sys.executable, "main.py"])
                sys.exit
            if event.key == pg.K_1: selected = 0
            if event.key == pg.K_2: selected = 1
            if event.key == pg.K_3: selected = 2

        if event.type == pg.MOUSEBUTTONDOWN:
            tx, ty = get_tile(event.pos)

            if 0 <= tx < COLS and 0 <= ty < ROWS:

                # BREAK (only solid)
                if event.button == 1:
                    if world[ty][tx] != AIR:
                        world[ty][tx] = AIR

                # PLACE (adjacent only)
                if event.button == 3:
                    if world[ty][tx] == AIR:
                        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                            if is_solid(tx+dx, ty+dy):
                                world[ty][tx] = hotbar[selected]
                                break

    # ---------- PLAYER PHYSICS ----------
    keys = pg.key.get_pressed()
    dx = 0

    if keys[pg.K_a]:
        dx = -4
    if keys[pg.K_d]:
        dx = 4
    if keys[pg.K_SPACE] and on_ground:
        vel_y = JUMP_FORCE

    vel_y += GRAVITY
    dy = vel_y

    # Horizontal collision
    player.x += dx
    for y in range(ROWS):
        for x in range(COLS):
            if world[y][x] != AIR:
                if player.colliderect(x*TILE, y*TILE, TILE, TILE):
                    player.x -= dx

    # Vertical collision
    on_ground = False
    player.y += dy
    for y in range(ROWS):
        for x in range(COLS):
            if world[y][x] != AIR:
                rect = pg.Rect(x*TILE, y*TILE, TILE, TILE)
                if player.colliderect(rect):
                    if dy > 0:
                        player.bottom = rect.top
                        vel_y = 0
                        on_ground = True
                    elif dy < 0:
                        player.top = rect.bottom
                        vel_y = 0

    # ---------- DRAW ----------
    screen.fill(SKY)
    draw_world()
    screen.blit(plr_img, player)
    draw_hotbar()

    pg.display.flip()
    clock.tick(60)

pg.quit()
sys.exit()
